# goals/handlers/__init__.py
# Handlers subpackage

from .base import BaseGoalHandler, GoalHandler  # noqa: F401
